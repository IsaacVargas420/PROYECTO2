/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Asus
 */
import java.util.ArrayList;

public class Tienda {
    private String nombre;
    private ArrayList<Empleado> empleados;
    private ArrayList<Venta> ventasRealizadas;

    public Tienda(String nombre) {
        this.nombre = nombre;
        this.empleados = new ArrayList<>();
        this.ventasRealizadas = new ArrayList<>();
    }
    
    
    // Getters y setters                                                                                                                                                                                                                                                                                                                                                                  
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;                                             
    }

    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }

    public ArrayList<Venta> getVentasRealizadas() {
        return ventasRealizadas;
    }

    
    public void setVentasRealizadas(ArrayList<Venta> ventasRealizadas) {   
        this.ventasRealizadas = ventasRealizadas;
    }

    // Método para realizar una venta
    public Venta realizarVenta(Cliente cliente, Producto[] productos) {
        Venta nuevaVenta = new Venta(ventasRealizadas.size() +1 , cliente);
      
        for (Producto producto : productos) {
            nuevaVenta.agregarProducto(producto);
            producto.vender(1); // Suponiendo que se vende una unidad de cada producto
        }
        ventasRealizadas.add(nuevaVenta);
        System.out.println("Venta realizada correctamente.");
        return nuevaVenta;
    }

    // Método para contratar un empleado
    public void contratarEmpleado(Empleado empleado) {
        empleados.add(empleado);
        System.out.println("Empleado contratado: " + empleado.getNombre());
    }
    
    
    
    
}
