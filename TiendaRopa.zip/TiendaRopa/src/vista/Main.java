/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import modelo.Cliente;
import modelo.Empleado;
import modelo.Producto;
import modelo.Tienda;
import modelo.Venta;

/**
 *
 * @author Asus
 */
public class Main {
    public static void main(String[] args) {
        // Crear la tienda
        Tienda tienda = new Tienda("...Mi Tienda..."); 
        

        // Crear algunos clientes
        Cliente cliente1 = new Cliente(1, "jair" ,   "jair@example.com");
        Cliente cliente2 = new Cliente(2, "María", "maria@example.com");

        
           
        // Crear algunos productos
        
        Producto producto1 = new Producto(1, "Camiseta", 20.0, 50);
        Producto producto2 = new Producto(2, "Pantalón", 30.0, 30);
        Producto producto3 = new Producto(3, "Zapatos", 50.0, 20);

        // Realizar una venta
        Producto[] productosVenta = {producto1, producto2};
        Venta ventaRealizada = tienda.realizarVenta(cliente1, productosVenta);

        // Mostrar el recibo de la venta
        System.out.println(" ...Recibo de venta...");

        String recibo = ventaRealizada.generarRecibo();
        System.out.println(recibo);
        

        // Contratar  un empleado
        System.out.println("...Empleado...");
        Empleado empleado1 = new Empleado(1, "Pedro", "Vendedor", 1000.0);
        Empleado empleado2 = new Empleado( 1 , "isaac", "vendedor1", 2000.0);
        
        tienda.contratarEmpleado(empleado1);
                tienda.contratarEmpleado(empleado2);

        
        
               System.out.println("...venta por empleado...");

        // Realizar una venta del empleado
        tienda.realizarVenta(cliente2, new Producto[]{producto3});
                tienda.realizarVenta(cliente1, new Producto[]{producto1, producto2});

                
    }
}
