/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Asus
 */



import java.util.ArrayList;

public class Venta {
    private int idVenta;
    private Cliente cliente;
    private ArrayList<Producto> productosVendidos;
    private double totalVenta;

    public Venta(int idVenta, Cliente cliente) {
        this.idVenta = idVenta;
        this.cliente = cliente;
        this.productosVendidos = new ArrayList<>();
        this.totalVenta = 0.0;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public ArrayList<Producto> getProductosVendidos() {
        return productosVendidos;
    }

    public void setProductosVendidos(ArrayList<Producto> productosVendidos) {
        this.productosVendidos = productosVendidos;
    }

    public double getTotalVenta() {
        return totalVenta;
    }

    public void setTotalVenta(double totalVenta) {
        this.totalVenta = totalVenta;
    }
    

    // Método para agregar un producto a la venta
    public void agregarProducto(Producto producto) {
        productosVendidos.add(producto);
        totalVenta += producto.getPrecio();
    }

    // Método para calcular el total de la venta
    public double calcularTotalVenta() {
        return totalVenta;
    }

    // Método para generar un recibo de la venta
    public String generarRecibo() {
        StringBuilder recibo = new StringBuilder();// string builder contructor de cadenas de texto
        
        recibo.append("FACTURA\n");
        recibo.append("Cliente: " + cliente.getNombre() + "\n");
        recibo.append("Productos:\n"  );
        for (Producto producto : productosVendidos) {
            recibo.append("- " + producto.getNombre() + ": $" + producto.getPrecio() + "\n");
        }
        recibo.append("Total: $" + totalVenta + "\n");
        return recibo.toString();
    }
}

